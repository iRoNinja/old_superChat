const test = function (){console.log('Вызвано из консольки')}
module.exports ={test};